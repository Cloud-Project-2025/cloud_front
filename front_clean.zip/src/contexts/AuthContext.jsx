// src/contexts/AuthContext.jsx
import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { setToken, getToken, clearToken } from "../lib/auth";
import { loginReq, registerReq } from "../services/authService";
// import { meReq } from "../services/authService"; // 실제 서비스용 (예시)

const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);

  /* ---------------------------------------------------------------------- */
  /* 실제 서비스용 패턴 (백엔드 붙일 때 이렇게 바꿀 예정)                     */
  /* ---------------------------------------------------------------------- */
  /*
  useEffect(() => {
    const t = getToken();
    if (!t) {
      setReady(true);
      return;
    }

    // 토큰이 있으면 me API로 내 정보 확인
    meReq()
      .then((u) => setUser(u))
      .catch(() => {
        clearToken();
        setUser(null);
      })
      .finally(() => setReady(true));
  }, []);
  */

  /* ---------------------------------------------------------------------- */
  /* 현재 더미 테스트용: 로컬스토리지에 저장된 토큰만 간단히 체크            */
  /* 백엔드가 아직 없으니까, 단순히 "로그인이 되어 있었다" 정도만 복원       */
  /* ---------------------------------------------------------------------- */
  useEffect(() => {
    const t = getToken();
    if (!t) {
      setReady(true);
      return;
    }
    try {
      const raw = window.localStorage.getItem("eco-db:user");
      if (raw) {
        setUser(JSON.parse(raw));
      }
    } catch (e) {
      console.warn("Failed to restore dummy user:", e);
      clearToken();
    } finally {
      setReady(true);
    }
  }, []);

  // 로그인: 지금은 authService의 더미 loginReq 사용
  const login = async (email, password) => {
    const { token, user } = await loginReq({ email, password });
    if (!token) throw new Error("No token returned");

    setToken(token); // 토큰은 그냥 문자열만 저장
    setUser(user || { email });
    // 더미 복원을 위해 user 정보도 따로 저장
    window.localStorage.setItem("eco-db:user", JSON.stringify(user || { email }));
    return true;
  };

  const register = async (email, password) => {
    const { token, user } = await registerReq({ email, password });
    if (token) setToken(token);
    if (user) {
      setUser(user);
      window.localStorage.setItem("eco-db:user", JSON.stringify(user));
    }
    return true;
  };

  const logout = () => {
    clearToken();
    setUser(null);
    window.localStorage.removeItem("eco-db:user");
  };

  const value = useMemo(
    () => ({
      user,
      isAuthed: !!user,
      ready,
      login,
      logout,
      register,
    }),
    [user, ready]
  );

  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}

export function useAuth() {
  return useContext(AuthCtx);
}
