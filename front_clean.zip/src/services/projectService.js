// src/services/projectService.js
import axios from "axios";

const BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8080";

/* -------------------------------------------------------------------------- */
/*  실제 서비스용 코드 (백엔드 연결할 때 이 주석을 해제해서 사용)              */
/* -------------------------------------------------------------------------- */
/*
export async function createProject(payload) {
  // POST /projects
  const res = await axios.post(`${BASE_URL}/projects`, payload);
  return res.data; // 생성된 프로젝트 객체
}

export async function updateProject(id, payload) {
  // PUT /projects/{id}
  const res = await axios.put(`${BASE_URL}/projects/${id}`, payload);
  return res.data; // 수정된 프로젝트 객체
}

export async function deleteProject(id) {
  // DELETE /projects/{id}
  const res = await axios.delete(`${BASE_URL}/projects/${id}`);
  return res.data; // 보통 { success: true } or 204
}
*/

/* -------------------------------------------------------------------------- */
/*  현재 사용 중인 더미 테스트용 코드                                         */
/*  - 버튼/화면은 그대로 동작하지만 DB에는 저장/수정/삭제 되지 않음            */
/*  - 개발자 도구 Network 탭에서 API 호출 확인하고 싶을 때 위 실제 코드로 교체 */
/* -------------------------------------------------------------------------- */

export async function createProject(payload) {
  console.log("[DUMMY] createProject 호출", payload);
  // 실제라면 백엔드에서 id를 발급해 줄 것이라 가정
  return {
    id: Date.now(),
    ...payload,
  };
}

export async function updateProject(id, payload) {
  console.log("[DUMMY] updateProject 호출", { id, payload });
  return {
    id,
    ...payload,
  };
}

export async function deleteProject(id) {
  console.log("[DUMMY] deleteProject 호출", { id });
  return { success: true };
}
