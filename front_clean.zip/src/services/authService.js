// src/services/authService.js
import axios from "axios";
import { mockUsers } from "../mock/mockData";

// ✅ 공통 BASE URL (나중에 백엔드 실제 주소로 맞추기)
// 예) Vite 환경변수에 VITE_API_BASE_URL="http://localhost:8080" 이런 식으로 넣어두면 좋음
const BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8080";

/* -------------------------------------------------------------------------- */
/*  실제 서비스용 코드 (백엔드 연결할 때 이 주석을 해제해서 사용)              */
/* -------------------------------------------------------------------------- */
/*
export async function loginReq({ email, password }) {
  const res = await axios.post(`${BASE_URL}/account/email/signin`, {
    email,
    password,
  });
  // 백엔드에서 { token, user } 형식으로 내려준다고 가정
  return res.data;
}

export async function registerReq({ email, password }) {
  const res = await axios.post(`${BASE_URL}/account/email/signup`, {
    email,
    password,
  });
  return res.data; // { token, user }
}
*/

/* -------------------------------------------------------------------------- */
/*  현재 사용 중인 더미 테스트용 코드 (프론트만 동작)                          */
/*  - 보고서에서는 "백엔드 API 설계는 완료, 현재는 더미 계정으로 테스트" 라고 쓰면 됨 */
/* -------------------------------------------------------------------------- */

export async function loginReq({ email, password }) {
  // 비밀번호는 지금은 체크 안 함 (원하면 같이 검사해도 됨)
  const found = mockUsers.find((u) => u.email === email);

  if (!found) {
    // 백엔드에서 401을 줄 상황
    throw new Error("Invalid email or password");
  }

  // 진짜였다면 JWT 같은 토큰이 올 것이라고 가정하고 더미 토큰 생성
  return {
    token: `dummy-token-${email}`,
    user: found, // { id, email, role }
  };
}

export async function registerReq({ email, password }) {
  // 지금은 실제 회원가입 X, 그냥 "가입된 것처럼" 응답만 돌려줌
  // (보고서에 "현재 회원가입은 더미로 처리"라고 적어두면 됨)
  const fakeUser = {
    id: Date.now(),
    email,
    role: "user",
  };

  return {
    token: `dummy-token-${email}`,
    user: fakeUser,
  };
}
