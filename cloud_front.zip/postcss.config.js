export default {
  plugins: {
    "@tailwindcss/postcss": {}, // ← v4에서는 이 패키지를 사용
    autoprefixer: {},
  },
}
